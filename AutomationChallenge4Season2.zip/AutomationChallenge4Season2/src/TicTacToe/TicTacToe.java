package TicTacToe;
import java.util.*;

public class TicTacToe {
static String[] board;
	static String turn;
static String checkWinner()
	{
		for (int a = 0; a < 8; a++) {
			String line = null;

			switch (a) {
			case 0:
				line = board[0] + board[1] + board[2];
				break;
			case 1:
				line = board[3] + board[4] + board[5];
				break;
			case 2:
				line = board[6] + board[7] + board[8];
				break;
			case 3:
				line = board[0] + board[3] + board[6];
				break;
			case 4:
				line = board[1] + board[4] + board[7];
				break;
			case 5:
				line = board[2] + board[5] + board[8];
				break;
			case 6:
				line = board[0] + board[4] + board[8];
				break;
			case 7:
				line = board[2] + board[4] + board[6];
				break;
			}
			//For X winner
			if (line.equalsIgnoreCase("XXX")) {
				return "X";
			}

			// For O winner
			else if (line.equalsIgnoreCase("OOO")) {
				return "O";
			}
		}

		for (int a = 0; a < 9; a++) {
			if (Arrays.asList(board).contains(
					String.valueOf(a + 1))) {
				break;
			}
			else if (a == 8) {
				return "draw";
			}
		}


		return null;
	}

	

	public static void main(String[] args)
	{

		board = new String[9];
		turn = "X";
		int m, n,c, d, k;
		String winner = null;
		/*
		 * Scanner sc = new Scanner(System.in);
		 * System.out.println("Enter the number of rows and columns of first matrix");
		 * System.out.print("Input : "); String nu = sc.next(); String[]
		 * num=nu.split("\\*"); n=Integer.parseInt(num[0]); m=Integer.parseInt(num[1]);
		 */	     
		System.out.println("Enter Input");
		Scanner in = new Scanner(System.in);
		for (int a = 0; a < 9; a++) {
			board[a] = in.next();
		}					
		winner = checkWinner();	
		if (winner.equalsIgnoreCase("draw")) {
			System.out.println(
					"It's a draw! Thanks for playing.");
		}

		// For winner -to display Congratulations! message.
		else {
			System.out.println(
					"Congratulations! " + winner
					+ "'s have won! Thanks for playing.");
		}
		in.close();
	}
}
//https://www.geeksforgeeks.org/tic-tac-toe-game-in-java/



