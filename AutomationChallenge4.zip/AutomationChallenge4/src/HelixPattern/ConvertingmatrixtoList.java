package HelixPattern;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ConvertingmatrixtoList {	
	
	public static void main(String[] args) {
		System.out.println("Enter the Number of Rows in Matrix:");
		try (Scanner sc = new Scanner(System.in)) {
			int RowCount=sc.nextInt();
			System.out.println("Enter the Number of Columns in Matrix:");
			Scanner scc=new Scanner(System.in);
			int ColumnCount=scc.nextInt();
			System.out.println("Enter the Elements in Matrix one by one by pressing Enter key:");	
			Scanner mat=new Scanner(System.in);
			int[][] twoDArrayInput = new int[RowCount][ColumnCount];
			for (int i = 0; i < RowCount; i++) 
			{
			    for (int j = 0; j < ColumnCount; j++) 
			    {
			    	twoDArrayInput[i][j] = mat.nextInt();
			    }
			}	
			System.out.println("The Results will be  "+spiralOrder(twoDArrayInput));
		}
	}
	private static List<Integer> spiralOrder(int[][] matrix) {
		List<Integer> result = new ArrayList<>();
		int rows = matrix.length;
		int columns = matrix[0].length;
		int up = 0;
		int left = 0;
		int right = columns - 1;
		int down = rows - 1;
		while (result.size() < rows * columns) {			
			for (int col = left; col <= right; col++) {// Left to right direction.
				result.add(matrix[up][col]);
			}			
			for (int row = up + 1; row <= down; row++) {// Top down direction
				result.add(matrix[row][right]);
			}			
			if (up != down) {// Make sure we are on a different row// Right to left direction				
				for (int col = right - 1; col >= left; col--) {
					result.add(matrix[down][col]);
				}
			}			
			if (left != right) {// Make sure we are on a different column// Bottom up direction				
				for (int row = down - 1; row > up; row--) {
					result.add(matrix[row][left]);
				}
			}
			left++;			right--;			up++;			down--;
		}
		return result;
	}
}
	


