package Json;

import java.awt.Window.Type;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONString;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.HashMultimap;
import com.google.common.collect.MapDifference;
import com.google.common.collect.Maps;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.reflect.TypeToken;


import org.codehaus.jackson.type.TypeReference;
import org.apache.commons.io.FileUtils;

import org.apache.poi.ss.formula.functions.T;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;



public final class ComparingJSONFiles  {	
	static int flag=2;
	static JsonElement o1=null;

	private ComparingJSONFiles() {
		throw new AssertionError("No instances for you!");
	}

	public static Map<String, Object> flatten(Map<String, Object> map) {
		return map.entrySet().stream()
				.flatMap(ComparingJSONFiles::flatten)
				.collect(LinkedHashMap::new, (m, e) -> m.put("/" + e.getKey(), e.getValue()), LinkedHashMap::putAll);
	}

	public  static Stream<Map.Entry<String, Object>> flatten(Map.Entry<String, Object> entry) {

		if (entry == null) {
			return Stream.empty();
		}

		if (entry.getValue() instanceof Map<?, ?>) {
			return ((Map<?, ?>) entry.getValue()).entrySet().stream()
					.flatMap(e -> flatten(new AbstractMap.SimpleEntry<>(entry.getKey() + "/" + e.getKey(), e.getValue())));
		}

		if (entry.getValue() instanceof List<?>) {	        	
			List<T> list = (List<T>) entry.getValue();			
			return IntStream.range(0, list.size())
					.mapToObj(i -> new AbstractMap.SimpleEntry<String, Object>(entry.getKey() + "/" + i, list.get(i)))
					.flatMap(ComparingJSONFiles::flatten); 		}

		return Stream.of(entry);
	}

	static String path = System.getProperty("user.dir");

	public static JsonElement File1() {
		JsonParser jsonParser = new JsonParser();
		JsonElement jsonElement = null;
		String otherFolder = path + "\\jsonFiles\\jsonfile1.json";

		try (FileReader reader = new FileReader(otherFolder
				)) {
			jsonElement = (JsonElement) jsonParser.parse(reader);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return jsonElement;
	}
	public static JsonElement File2() {
		JsonParser jsonParser = new JsonParser();
		JsonElement jsonElement = null;
		String otherFolder = path + "\\jsonFiles\\jsonfile2.json";
		try (FileReader reader = new FileReader(
				otherFolder)) {
			jsonElement = (JsonElement) jsonParser.parse(reader);				

		} catch (Exception e) {
			e.printStackTrace();
		}
		return jsonElement;
	}

	public static void excelCalculations(String Diff) throws IOException {
		String filePath = "C:\\Users\\user\\Desktop\\Output.xlsx";
		File file =new File(filePath);
		FileInputStream fis = new FileInputStream(file); 

		Workbook DataWorkBook=null;
		DataWorkBook=new  XSSFWorkbook(fis);		
		org.apache.poi.ss.usermodel.Sheet sheet=DataWorkBook.getSheet("Sheet1"); 

		        XSSFRow row = (XSSFRow) sheet.createRow(2);// Return type of getRow method is a XSSFRow. 

				// Create a third cell in the second row and set the cell value 'Pass'. 
				XSSFCell cell = row.createCell(2); 
				cell.setCellValue("Pass"); // This method returns nothing. 

				// Or, In one line code: 
				sheet.getRow(2).createCell(2).setCellValue(Diff); 

				// Similarly, for the third row and third cell. 
				sheet.createRow(3).createCell(3).setCellValue("Fail"); 
				sheet.createRow(4).createCell(4).setCellValue("Pass"); 

				// Create an object of FileOutputStream class to create the write data in excel file. 
				FileOutputStream fos = new FileOutputStream(filePath); 

				// Write data in the excel file. 
				//wb.write(fos); 

				// Close the output stream. 
				fos.close(); 
				System.out.println("Result Written Successfully"); 


	}   


	public static void main(String[] args) throws IOException {	    	
		Gson gson = new Gson();
		java.lang.reflect.Type type = new TypeToken<Map<String, Object>>(){}.getType();
		Map<String, Object> leftMap = gson.fromJson(File1(), type);
		Map<String, Object> rightMap = gson.fromJson(File2(), type);


		Map<String, Object> leftFlatMap = ComparingJSONFiles.flatten(leftMap);
		Map<String, Object> rightFlatMap = ComparingJSONFiles.flatten(rightMap);

		MapDifference<String, Object> difference = Maps.difference(leftFlatMap, rightFlatMap);

		System.out.println("\n\n****************************************************************************");
		System.out.println("REPORTS IN DETAILED FORMAT");
		System.out.println("****************************************************************************");

		System.out.println("\n\nEntries only on File 1 \n--------------------------");
		difference.entriesOnlyOnLeft()
		.forEach((key, value) -> System.out.println(key + ": " + value));
		//excelCalculations(difference);

		System.out.println("\n\nEntries only on File 2\n--------------------------");
		difference.entriesOnlyOnRight()
		.forEach((key, value) -> System.out.println(key + ": " + value));

		System.out.println("\n\nEntries differing\n--------------------------");
		difference.entriesDiffering()
		.forEach((key, value) -> System.out.println(key + ": " + value));
		
	}

	

	
}


