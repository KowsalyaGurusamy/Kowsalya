package SubArray;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;

public class Main {	
	static String val;
	static String vaa="";
	    public static String dfs(Node root, Map<String, Integer> f) {
	        // Base condition
	        if (root == null) return "";
	        String s = "(" + Integer.toString(root.data);	        
	        for (Node child : root.children) {
	            s += dfs(child, f);
	        }
	        s += ')';
	        f.put(s, f.getOrDefault(s, 0) + 1);
	        return s;
	    }
	 
	    public static int duplicateSubtreeNaryTree(Node root) {
	        Map<String, Integer> f = new HashMap<>();
	        dfs(root, f);
	        int ans = 0;
	        
	        for (Map.Entry<String, Integer> entry : f.entrySet()) {
	            if (entry.getValue() > 1) 
	            {
	            	ans++;
	            	val=entry.getKey();
	            	vaa=vaa+" "+val;
	            }
	             
	        }
	        if (vaa.equals("")) {
	        	 System.out.println("No nodes repeating");
			}else
			{
				 System.out.println("The nodes which are repeating   :"+vaa);
			}
	       
	        return ans;
	        
	       
	    }
	    static String path=System.getProperty("user.dir");
		private static String filepath=path+"\\src\\SubArray\\";
		
		
	    public static void main(String[] args) throws FileNotFoundException { 	
	    	
            Scanner sc=new Scanner(System.in);
			
			System.out.println("File is present in the path  :"+filepath);
			System.out.print("Enter file name  "
					+ ":");
			String filename=sc.nextLine();
			//String filename="NodeInput.txt";
			Scanner sca=new Scanner(new File(filepath+filename)); 
			int Flag=0;
			String total=sca.nextLine();
			
			String[] arr=total.split("N");
			int a=arr.length;
			
			String s=arr[0].trim();			
			int node1=Integer.parseInt(s);
			Node root = new Node(1);
			
			
			String sub = "";
			String[] val=arr[1].trim().split(" ");
			for (int i = 1; i <=val.length; i++) {				
				 sub=val[i-1];
				 int subint=Integer.parseInt(sub);
				 root.children.add(new Node(subint));
			}
			
			String[] val1=arr[2].trim().split(" ");
			for (int i = 1; i <=val1.length; i++) {				
				 sub=val1[i-1];
				 int subint=Integer.parseInt(sub);
				 root.children.get(0).children.add(new Node(subint));
			}
			
			if (a==4) {
				String[] val2=arr[3].trim().split(" ");
				for (int i = 1; i <=val2.length; i++) {				
					 sub=val2[i-1];
					 int subint=Integer.parseInt(sub);
					 root.children.get(1).children.add(new Node(subint));
				}
				
			}
			
			System.out.println("Output: "+duplicateSubtreeNaryTree(root));		
			
	        
	    }
	}


