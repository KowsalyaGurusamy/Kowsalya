package SubArray;
import java.util.*;            
 class Node {	
	    public int data;
	    public List<Node> children;
	    public Node(int val) { data = val; children = new ArrayList<Node>(); }
	}
	 
	
	 
	   


