package Json;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;
import java.util.Map.Entry;
import java.util.stream.Collectors;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.JSONException;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;


import com.google.gson.*;


public class FileForChallenge {	

	static Set<JsonElement> setOfElements(JsonArray jsonArray) {
		Set<JsonElement> set = new HashSet<JsonElement>();
		for (Object j: jsonArray) {
			set.add((JsonElement) j);
		}
		return set;
	}
	static String path = System.getProperty("user.dir");
	public static void main(String[] args) throws IOException, ParseException, JSONException {	
		System.out.println("Results Ouptut file path -"+path +"\\Output.xlsx");
		System.out.println("Input file 1 path -"+path +"\\jsonFiles\\jsonfile1.json");
		System.out.println("Input file 2 path -"+path +"\\jsonFiles\\jsonfile2.json");
		deletecontents();
		
		JsonParser jsonParser = new JsonParser();
		JsonObject jsonObject = (JsonObject) jsonParser.parse(new FileReader(path +"\\jsonFiles\\jsonfile1.json"));
		JsonArray jsonArray = (JsonArray) jsonObject.get("menu");
		JsonObject jsonObject1 = (JsonObject) jsonParser.parse(new FileReader(path +"\\jsonFiles\\jsonfile2.json"));
		JsonArray jsonArray1 = (JsonArray) jsonObject1.get("menu");		
		Set<JsonElement> arr1elems =setOfElements(jsonArray);
		Set<JsonElement> arr2elems =setOfElements(jsonArray1);
		System.out.println("\nArrays match? " + arr1elems.equals(arr2elems));		
		Set<JsonElement> entriesinfile1only = new HashSet<JsonElement>();Set<JsonElement> entriesinfile2only = new HashSet<JsonElement>();
		Set<JsonElement> missingrecordsinjson2 = new HashSet<JsonElement>();Set<JsonElement> missingrecordsinjson1 = new HashSet<JsonElement>();		
		for (JsonElement je1 : arr1elems) {	//only json 1			
			int flag=0;
			for(JsonElement je2 : arr2elems){
				if (je1.equals(je2)) {flag=1;
				}
			}
			if (!(flag==1)) {
				entriesinfile1only.add(je1);					
			}
		}		
		for (JsonElement je1 : arr2elems) {	//only json 2			
			int flag=0;
			for(JsonElement je2 : arr1elems){
				if (je1.equals(je2)) {					
					flag=1;
				}
			}
			if (!(flag==1)) {
				entriesinfile2only.add(je1);					
			}
		}
		Object var=null;		Object var1=null;//to get mismatch records
		for (JsonElement jsonElement : entriesinfile1only) {	
			int flags=0;
			JsonObject rootObject = jsonElement.getAsJsonObject();
			for (JsonElement jsonElement1 : entriesinfile2only) {					
				JsonObject rootObject1 = jsonElement1.getAsJsonObject();
				for (Object key : rootObject.entrySet()) {							
					var=key;
					break;
				}
				for (Object key : rootObject1.entrySet()) {						
					var1=key;
					break;
				}
				if (var.equals(var1)) {					
					System.out.println("Records Mismatch -JSON 1: "+ rootObject+" JSON 2: " +rootObject1);	
					excelCalculations("Records Mismatch -JSON 1: "+ rootObject.toString()+" JSON 2: " +rootObject1.toString());
					flags=1;
					break;
				}	
			}
			if(!(flags==1))
			{
				missingrecordsinjson2.add(rootObject);

			}
		}
		for (JsonElement jsonElement : missingrecordsinjson2) {	
			System.out.println("\nRecord Missing in Json 2: "+jsonElement);
			excelCalculations("Record Missing in Json 2  :  "+jsonElement.toString());
		}
		//for json 2
		JsonObject rootObject1=null;
		for (JsonElement jsonElement : entriesinfile2only) {	
			int flags=0;
			JsonObject rootObject = jsonElement.getAsJsonObject();
			for (JsonElement jsonElement1 : entriesinfile1only) {					
				rootObject1 = jsonElement1.getAsJsonObject();
				for (Object key : rootObject.entrySet()) {						
					var=key;
					break;
				}
				for (Object key : rootObject1.entrySet()) {					
					var1=key;
					break;
				}
				if (var.equals(var1)) {
					flags=1;
					break;
				}	
			}
			if(!(flags==1))
			{
				missingrecordsinjson1.add(rootObject);

			}
		}
		for (JsonElement jsonElement : missingrecordsinjson1) {	
			System.out.println("\nRecord Missing in Json 1: "+jsonElement.toString());	
			excelCalculations("Record Missing in Json 1  :  "+jsonElement.toString());
		}
	}
	
	static int rowid = 1; static int cellid = 1;
	static int Flag=1;
	public static void excelCalculations(String Mismatch) throws IOException {
		String filePath = path +"\\Output.xlsx";
		File file =new File(filePath);
		FileInputStream fis = new FileInputStream(file); 
		Workbook DataWorkBook=null;
		DataWorkBook=new  XSSFWorkbook(fis);		
		Sheet datasheet=DataWorkBook.getSheet("Results");				
		Row row = datasheet.createRow(rowid++);    
		Cell cell = row.createCell(1);
		cell.setCellValue(Mismatch);
		FileOutputStream fos = new FileOutputStream(filePath); 	 
		DataWorkBook.write(fos);
		//fos.flush();
		fos.close();		
		DataWorkBook.close();	

	} 
	
	public static void deletecontents() throws IOException
	{
		String filePath = path +"\\Output.xlsx";
		File file =new File(filePath);
		FileInputStream fis = new FileInputStream(file); 
		Workbook DataWorkBook=null;		
		DataWorkBook=new  XSSFWorkbook(fis);	
		DataWorkBook.removeSheetAt(0);
		DataWorkBook.createSheet("Results");
		FileOutputStream fos = new FileOutputStream(filePath); 	 
		DataWorkBook.write(fos);
		//fos.flush();
		fos.close();		
		DataWorkBook.close();
	}
	
	

}














