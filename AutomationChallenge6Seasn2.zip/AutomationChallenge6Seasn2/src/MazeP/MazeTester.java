package MazeP;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;


public class MazeTester{
	static String path=System.getProperty("user.dir");
	private static String filepath=path+"\\src\\MazeP\\";
	public static void main(String[] args) throws FileNotFoundException
	{
		//String filename="Mazeinp.txt";
		Scanner sc=new Scanner(System.in);
		
		System.out.println("File is present in the path  :"+filepath);
		System.out.print("Enter file name  :");
		String filename=sc.nextLine();
		Maze laby=new Maze(filepath+filename);
		//System.out.println(laby);
		

		MazeSolver labsol=new MazeSolver(laby);
		if (labsol.traverse(0,0)) {
			System.out.println("The maze traverse is scucessful");

		}else
		{
			System.out.println("The maze traveerse is not scucessful");
		}
		//System.out.println(laby);
	}

}






