package guessNumberPackage;
import java.awt.HeadlessException;
import javax.swing.JOptionPane;

public class guessNumberClass {

	public static void guessConditions(int trials)
	{			
		try {
			int max=10;int min=1;
			//To get Random number from 1-10 and not 0;
			int randomnumber = (int)(Math.random()*(max-min+1)+min);  
			System.out.println(randomnumber);		
			JOptionPane.showMessageDialog(null,"A Number is choosen betwen 1 to 10 by computer in random manner","Guess Number Quiz",JOptionPane.INFORMATION_MESSAGE);
			JOptionPane.showMessageDialog(null, "Guess the number by Entering input in 5 trials","Guess Number Quiz",JOptionPane.PLAIN_MESSAGE);


			for (int i = 1; i <= trials; i++) {			
				String inputmessage=JOptionPane.showInputDialog("Enter the Guess here");
				int guess=Integer.parseInt(inputmessage); 

				if (!(guess<=0 ||guess>10)) {			
					if (guess==randomnumber) {					
						JOptionPane.showMessageDialog(null, "You Guessed the number in "+i+ " Attempts","Congratulations!" ,JOptionPane.PLAIN_MESSAGE, null);
						break;
					} else if(guess>randomnumber) {
						JOptionPane.showMessageDialog(null,"Your Guess is High!","Guess Number Quiz",JOptionPane.INFORMATION_MESSAGE);
					} else
					{
						JOptionPane.showMessageDialog(null,"Your Guess is Low!","Guess Number Quiz",JOptionPane.INFORMATION_MESSAGE);
					}
				}else
				{
					JOptionPane.showMessageDialog(null,  "Guess the number in the range 1-10","Invalid Input -Hence Terminating", JOptionPane.ERROR_MESSAGE, null);
					break;
				}
				if (i==trials) {
					JOptionPane.showMessageDialog(null,"The Number to be guessed is "+randomnumber,"You have Exhausted the trials", JOptionPane.ERROR_MESSAGE, null);
				}
			}
		} catch (HeadlessException e) {			
			e.printStackTrace();
		} catch (NumberFormatException e) {			
			e.printStackTrace();
		}


	}

	public static void main(String[] args) {		
		guessConditions(5);
	}
}
