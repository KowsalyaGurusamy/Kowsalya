package StarPattern;

import java.util.Iterator;
import java.util.Scanner;

public class hollowKPattern {
	public static void main(String args[]) 
	{ 
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter the number of rows: ");
		int rows=sc.nextInt();    //get input from user
		for(int i=1; i<=rows; i++){//parent for loop lterate rows
		  for(int j=i; j<=rows; j++){		  
		  if(i==1 || j==i || j==rows){
		     System.out.print("*"); //print star
		     }
		     else{
		     System.out.print(" ");
		}
		}
		System.out.println();//move to next line
		}	
		int j;
		
	      for( int i=2;i<=rows;i++){
	         if(i==2 || i==rows)
	         for(  j=1;j<=i;j++){
	            System.out.print("*");
	         } else {
	             for( j=1;j<=i;j++){
	                if(j==1 || j==i)
	                   System.out.print("*");
	                else
	                   System.out.print(" ");
	            }
	         }
	      System.out.println();
	      }
	   }
	}




