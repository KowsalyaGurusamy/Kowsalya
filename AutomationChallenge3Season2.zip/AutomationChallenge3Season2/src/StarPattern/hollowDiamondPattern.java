package StarPattern;
import java.util.Scanner;  
public class hollowDiamondPattern {	
	 
private static Scanner sc;
	//https://www.onlinegdb.com/online_java_compiler
	public static void main(String[] args) {
		sc = new Scanner(System.in);
		
		int i, j, k;
		
		System.out.print("Enter Hollow Diamond Pattern Rows = ");
		int rows = sc.nextInt();
		
        if (rows%2==0) {
        	System.out.println("Cannot print the pattern with even number of lines");
		}else
		{
			System.out.println("Printing Hollow Diamond Star Pattern");		
		
		for (i = 1 ; i <= rows/2+1; i++ ) 
		{
			for (j = 1 ; j <= rows - i; j++ ) 
			{
				System.out.print(" ");	
			}
			for (k = 1 ; k <= i * 2 - 1; k++ ) 
			{
				if (k == 1 || k == i * 2 - 1) {
					System.out.print("*");
				}
				else {
					System.out.print(" ");
				}
			}
			System.out.println();
		}
		int rows1=rows/2+1;
		
		for (i = rows1 - 1 ; i > 0; i-- ) 
		{
			for (j = 1 ; j <= rows - i; j++ ) 
			{
				System.out.print(" ");
			}
			for (k = 1 ; k <= i * 2 - 1; k++ ) 
			{
				if (k == 1 || k == i * 2 - 1) {
					System.out.print("*");
				}
				else {
					System.out.print(" ");
				}
			}
			System.out.println();
		}
	}
	}
}
	


