package subsetPackage;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class creatingSubsetSum {
	
	public static void addingIntegers()
	{
		ArrayList<Integer> lst=new ArrayList<Integer>();
		lst.add(9);
		lst.add(10);
		lst.add(1);
		lst.add(0);
		Collections.sort(lst,Collections.reverseOrder());
		System.out.println(lst);
		int sum[];
		for (int i = 0; i < lst.size(); i++) {
			System.out.println(lst.get(i));
			
			
		}
		
	}
	public static void main(String[] args) {		
		addingIntegers();
	}
}
