package Strings;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class LongestCommon {

	public static void  lcs() throws IOException
	{
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Longest Common Substring Algorithm Test\n");	 
		System.out.println("Enter string 1");
		String str1 = br.readLine();	 
		System.out.println("Enter string 2");
		String str2 = br.readLine();
		int l1 = str1.length();
		int l2 = str2.length();

		int[][] arr = new int[l1 + 1][l2 + 1];
		int len = 0, pos = -1;int len1 = 0, pos1 = -1;int flag=0;

		for (int x = 1; x < l1 + 1; x++)
		{
			for (int y = 1; y < l2 + 1; y++)
			{
				if (str1.charAt(x - 1) == str2.charAt(y - 1))
				{
					arr[x][y] = arr[x - 1][y - 1] + 1;
					if (arr[x][y] >= len)
					{
						if (arr[x][y]==len) {
							len1 = arr[x][y];
							pos1 = x;
							flag=flag+1;

						}else
						{
							len = arr[x][y];
							pos = x;

						}
					}               
				}
				else
					arr[x][y] = 0;

			}
		} 
		if (!(len>0)) {
			System.out.println("No Longest Substring Found");

		}	else
		{
			String result = str1.substring(pos - len, pos);
			System.out.println("\nLongest Common Substring : "+result);
			if (flag>0 &&len==len1) {
				String result1 = str1.substring(pos1 - len1, pos1);
				System.out.println("\nLongest Common Substring : "+result1);
		}
		}



	}

	/** Main Function **/
	public static void main(String[] args) throws IOException
	{    

		lcs();

	}
}


