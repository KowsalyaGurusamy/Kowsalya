package OddandEvenSeq;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;

public class oddandEvenFinal {

	static void evenodd_naive(int arr[]) {
		ArrayList<Integer> addt=new ArrayList<>();
		int ans = 0;
		int count = 0;
		String val="";
		String value1="";
		HashMap<Integer, String> squares =   new HashMap<Integer, String>();
		
		for (int i = 0; i < arr.length; i++) {			
			count = 1;	
			int flag=0;
			int flags=0;
			for (int j = i + 1; j < arr.length; j++) {
				if ((arr[j - 1] % 2 == 0 && arr[j] % 2 != 0) || (arr[j - 1] % 2 != 0 && arr[j]
						% 2 == 0)) {
					count++;
					flag++;
					if (flag==1) {
						val=val+arr[j-1]+arr[j];
					}else
					{
						val=val+arr[j];	
					}

				} else break;
			}	    
			ans = Math.max(ans, count); 
			if (count>ans||count==ans) {				
					value1=val;						
					squares.put(count, val);					
					//System.out.println(squares);					
							
			}else
			{
				val="";
			}

		}
		

		
		if (value1=="") {
			System.out.println("There is no alternating substring in the given input ");
		}else
		{

			System.out.println("The value of the longest even-odd subarray is "+value1);
			System.out.println("The length of the longest even-odd subarray is "+ans);
		}



	}

	public static void main(String args[]) {
		System.out.println("Please provide the input :");
		// Read and parse the input numbers
		Scanner scanner = new Scanner(System.in);

		String inputLine = scanner.nextLine();
		//String[] numbers = inputLine.split("[ ()]+");
		char[] numbers = inputLine.toCharArray();
		int[] nums = new int[numbers.length];
		for (int i = 0; i < nums.length; i++) {
			nums[i] = Integer.parseInt(String.valueOf(numbers[i]));
		}
		evenodd_naive(nums);
	}
}


