import java.util.Scanner;

public class Repeatedpattern {	
	
	 public static int findPeriod(String A)
	    {
	        int length = A.length();	        
	        int period = -1;int flag=0;
	        int finalele=0;	int count=0;
	        String reversedStr = "";	        
	        int i = 0;
	        char[] charArray1 = A.toCharArray();
            for(char character : charArray1){
            	count=count+1;
            	if (character=='_')
            	{
            		break;
            	}
            }
            if (count<4) {    			
    			for (int i1 = 0; i1 < A.length(); i1++) {
    			  reversedStr = A.charAt(i1) + reversedStr;    			  
    			}
    			A=reversedStr;
			}
           
	        for (int j = 1; j < length; j++) {
	            int currChar = A.charAt(j);
	            int comparator = A.charAt(i);
	 
	            /*If current character matches with first
	             *character
	             *update period as the difference of j and i*/
	            if (currChar == comparator) {
	                period = (j - i);
	                if (period==finalele) {
	                	finalele=period;
	                	break;
					}
	                finalele=period;
	                i++;
	            }	          
	            else {
	                if (currChar == A.charAt(0)) {
	                    i = 1;
	                    period = j;
	                }
	                else {
	                    i = 0;
	                    period = -1;
	                }
	            }  	                     
	            
	        }    
	        
	        char[] charArray = A.toCharArray();
            for(char character1 : charArray){
            	
            	if (character1=='_')
            	{            		
					flag=flag+1;
					int val=flag%finalele;
					if (val==0) {
						System.out.println("The Output element is  "+A.charAt(finalele-1));
					}else {
					System.out.println("The Ouptut element is  "+A.charAt(val-1));
					break;
					}
				}else
            	{
					flag=flag+1;
            	}
             
            }	       
	        return period;
	    }
	    
	    public static void main(String[] args)
	    {
	    	System.out.println("Enter Input");
	    	Scanner sc=new Scanner(System.in);
	    	String testStrings=sc.next();	        
	        int n = testStrings.length();	       
	            if (findPeriod(testStrings) == -1)
	                System.out.println("No Pattern");          
	                
	        
	    }
	}


