package MazeP;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Iterator;
import java.util.Scanner;

public class Maze {
	
	private static final int open=0;
	private static final int tried=2;
	private static final int path=3;
	private int numberrows,numbercolumns;
	private int endrow,endcolumn;
	private int[][] grid;
	
	public Maze(String filename) throws FileNotFoundException
	{
		Scanner sca=new Scanner(new File(filename));
		numberrows=sca.nextInt();
		numbercolumns=sca.nextInt();
		grid=new int[numberrows][numbercolumns];
		for (int i = 0; i < numberrows; i++) 
			for (int j = 0; j < numbercolumns; j++) 
				grid[i][j]=sca.nextInt();
			
				sca.close();
				endrow=getRows()-1;
				endcolumn=getColumns()-1;
				
			
		
	}
		
		public void tryPosition(int row,int col)
		{
			grid[row][col]=tried;
		}
		public boolean solved(int row,int col)
		{
			return( row==endrow && col==endcolumn);
		}
		public int getRows()
		{
			return grid.length;
		}
		public int getColumns()
		{
			return grid[0].length;
		}
		public void markpath(int row,int col)
		{
			grid[row][col]=path;
		}
		
		public boolean validposition(int row,int column)
		{
			boolean result=false;
			if (row>=0&&row<grid.length&&column>=0&&column<grid[0].length) {
				if (grid[row][column]==open) {
					result=true;					
				}				
			}
			return result;
		}
		
		public String toString()
		{
			String result= "\n";
			for (int row = 0; row < grid.length; row++) {
				for (int col = 0; col < grid[row].length; col++) {
					result +=grid[row][col]+"";
					result+= "\n";
					
				}
				
			}
			return result;
		}
	

}
