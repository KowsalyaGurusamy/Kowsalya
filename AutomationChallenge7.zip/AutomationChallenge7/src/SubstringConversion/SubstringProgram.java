package SubstringConversion;
import java.util.*;
public class SubstringProgram {	
	static String make_String_S_to_T(String S, String T)
	{	    
	    boolean possible = false;	    
	    int input2 = T.length();	    
	    int N = S.length();	    
	    for (int i = 0; i <= input2; i++)
	    {	      
	        int prefix_length = i;	        
	        int suffix_length = input2- i;	        
	        String prefix = S.substring(0, prefix_length);	        	        
	        String suffix	 = S.substring(N - suffix_length, N);	        
	        if ((prefix + suffix).equals(T))
	        {
	        	String val=S.substring(prefix_length, N - suffix_length);
	        	int len= N - suffix_length-1; 	        	
	        	System.out.println("Can be Converted by removing "+val+"( A["+prefix_length+"] to A["+len+"] )to get "+prefix + suffix);
	            possible = true;
	            break;
	        }
	    }
	    if (possible)
	        return "***********";
	    else
	    {
	    	 System.out.println("Cannot be converted by removing one substring,Need to remove more Substring");
	        return "***********";
	    }
	}	 
	
	public static void main(String[] args)
	{
		
		  System.out.println("Enter String A"); Scanner string1=new Scanner(System.in);
		  String input1 =string1.next(); System.out.println("Enter String B"); Scanner
		  string2=new Scanner(System.in); String input2 =string2.next();		 
		   System.out.print(make_String_S_to_T(input1, input2));			
	}
	}
	 

