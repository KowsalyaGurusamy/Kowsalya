package subsetPackage;
//Java program to print  
// equal sum sets of array. 
import java.io.*; 
import java.util.*; 

public class subset {  

	// Function to print equal sum sets of array. 
	public static void printEqualSumSets(int []arr, int n) 
	{ 
		int i, currSum, sum = 0; 

		//To find sum of array
		for (i = 0; i < arr.length; i++) 
			sum =sum+ arr[i]; 

		// Check sum is even or odd.If odd then array cannot be partitioned. Print -1 and return. 
		if ((sum & 1) == 1)  
		{ 
			System.out.print("-1"); 
			return; 
		} 

		// Divide sum by 2 to find 		
		int k = sum >> 1; 

		// Boolean DP table to store		 
		boolean [][]dp = new boolean[n + 1][k + 1]; 

		// If number of elements are zero,then no sum can be obtained. 
		for (i = 1; i <= k; i++) 
			dp[0][i] = false; 

		//As per rule first column can be made as True 
		for (i = 0; i <= n; i++) 
			dp[i][0] = true; 

		// Fill the DP table in bottom up manner. 
		for (i = 1; i <= n; i++)  
		{ 
			for (currSum = 1;currSum <= k; currSum++)  
			{ 

				// until the column reaches array value corresponding DP values can be copied from previous rows 
				dp[i][currSum] = dp[i - 1][currSum]; 

				// check the previous elemnt,if True put the same else do sum-array value,go to previous row and fetch element 
				if (arr[i - 1] <= currSum) 
					dp[i][currSum] = dp[i][currSum] |  
					dp[i - 1][currSum - arr[i - 1]]; 
			} 
		} 

		// Required sets set1 and set2. 
		List<Integer> set1 = new ArrayList<Integer>(); 
		List<Integer> set2 = new ArrayList<Integer>(); 

		// If partition is not possible print -1 and return. If the last element in DP table is F then partioning is not possible
		if (!dp[n][k])  
		{ 
			System.out.print("-1	"); 
			return; 
		} 

		// Start from last  
		// element in dp table. 
		i = n; 
		currSum = k; 

		while (i > 0 && currSum >= 0)  
		{ 

			// If current element does  
			// not contribute to k, then  
			// it belongs to set 2. 
			if (dp[i - 1][currSum])  
			{ 
				i--; 
				set2.add(arr[i]); 
			} 

			// If current element contribute 
			// to k then it belongs to set 1. 
			else if (dp[i - 1][currSum - arr[i - 1]])  
			{ 
				i--; 
				currSum -= arr[i]; 
				set1.add(arr[i]); 
			} 
		} 

		// Print elements of both the sets. 
		System.out.print("Set 1 elements: "); 
		for (i = 0; i < set1.size(); i++)  
			System.out.print(set1.get(i) + " "); 

		System.out.print("	Set 2 elements: "); 

		for (i = 0; i < set2.size(); i++)  
			System.out.print(set2.get(i) + " ");  
	} 

	
	public static void main(String args[]) 
	{ 		
		int []arr = new int[]{5,2,3}; 
		int n = arr.length; 
		printEqualSumSets(arr, n); 
	} 
} 

//DP table for {5,2,7}

//  0 1 2 3 4 5 6 7
//0 T F F F F F F F
//1 T F F F F T F F
//2 T F T F F T F T
//3 T F T F F T F T

